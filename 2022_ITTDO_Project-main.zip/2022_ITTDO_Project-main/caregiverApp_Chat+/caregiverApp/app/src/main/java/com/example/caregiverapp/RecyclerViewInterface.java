package com.example.caregiverapp;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
