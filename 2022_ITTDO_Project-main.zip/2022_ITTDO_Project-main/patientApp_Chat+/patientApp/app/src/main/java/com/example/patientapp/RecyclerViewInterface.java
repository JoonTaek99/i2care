package com.example.patientapp;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
